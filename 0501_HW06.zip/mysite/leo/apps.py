from django.apps import AppConfig


class LeoConfig(AppConfig):
    name = 'leo'
